while true; do
PID=$(pgrep -f "app.py")
if [ -z "$PID" ]; then
    bash runpy.sh "app.py" start
fi
sleep 2
done
