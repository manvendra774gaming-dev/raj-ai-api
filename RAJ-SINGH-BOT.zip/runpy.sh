#!/usr/bin/env bash

BOT_FILE="$1"
ACTION="$2"
PID_FILE="${BOT_FILE}.pid"

start_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo "Bot already running (PID: $PID)"
            return
        fi
    fi

    echo "Starting $BOT_FILE ..."
    python $BOT_FILE &
    echo $! > "$PID_FILE"
    echo "Started (PID: $(cat $PID_FILE))"
}

stop_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        echo "Stopping bot (PID: $PID)..."
        kill -9 $PID 2>/dev/null
        rm -f "$PID_FILE"
        echo "Bot stopped."
    else
        echo "Bot not running."
    fi
}

status_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo "Bot is running (PID: $PID)"
        else
            echo "Bot PID file exists but process not running."
        fi
    else
        echo "Bot is not running."
    fi
}

restart_bot() {
    stop_bot
    sleep 1
    start_bot
}

case "$ACTION" in
start) start_bot ;;
stop) stop_bot ;;
status) status_bot ;;
restart) restart_bot ;;
*) 
    echo "Usage: bash runpy.sh <file.py> {start|stop|restart|status}"
    exit 1
    ;;
esac
