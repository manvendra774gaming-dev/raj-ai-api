#!/bin/bash

# *** पहला ज़रूरी बदलाव यहाँ करें: ***
# यहां /path/to/your/bot/folder की जगह, अपने बॉट वाले फ़ोल्डर का
# पूरा पाथ (जैसे: /data/data/com.termux/files/home/ffbot) डालें।
BOT_DIRECTORY="/path/to/your/bot/folder"

# *** दूसरा ज़रूरी बदलाव यहाँ करें: ***
# अगर आपकी main file का नाम main.py नहीं है, तो उसे यहाँ बदलें।
MAIN_FILE="main.py"

# Termux में आपके बॉट फ़ोल्डर में जाने के लिए:
cd "$BOT_DIRECTORY"

echo "___________________________________"
echo "Free Fire TCP Bot Status Panel"
echo "___________________________________"
echo "1. Bot START (Foreground)"
echo "2. Bot START (Background & Keep running)"
echo "3. Bot STOP/Check (Running in background)"
echo "4. Exit"
echo "___________________________________"

read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        echo "Starting Bot in Foreground..."
        python "$MAIN_FILE"
        ;;
    2)
        echo "Starting Bot in Background (Use Option 3 to Stop)..."
        # nohup यह सुनिश्चित करता है कि Termux बंद करने पर भी Bot चलता रहे।
        # Output को log.txt में सेव किया जाएगा।
        nohup python "$MAIN_FILE" > log.txt 2>&1 &
        echo "Bot is now running in the background (PID: $!)."
        ;;
    3)
        echo "Checking/Stopping Background Bot..."
        # Running Python processes को ढूंढे
        PIDS=$(pgrep -f "python $MAIN_FILE")
        if [ -z "$PIDS" ]; then
            echo "No running bot found."
        else
            echo "Bot is running with PIDs: $PIDS"
            read -p "Do you want to STOP the bot? (y/n): " stop_choice
            if [ "$stop_choice" == "y" ]; then
                kill $PIDS
                echo "Bot stopped successfully."
            fi
        fi
        ;;
    4)
        echo "Exiting Panel."
        ;;
    *)
        echo "Invalid option. Please choose a number between 1 and 4."
        ;;
esac

