#!/usr/bin/env bash

# COLORS
CYAN="\033[1;36m"
GREEN="\033[1;32m"
RED="\033[1;31m"
BLUE="\033[1;34m"
YELLOW="\033[1;33m"
MAGENTA="\033[1;35m"
RESET="\033[0m"
GREY="\033[1;30m"

# Single bot filename
BOT="app.py"

# NORMAL 3D BUTTON
button_normal() {
echo -e "      ${CYAN}╔════════════════════════╗${RESET}"
echo -e "      ${CYAN}║${RESET}  $1${RESET}"
echo -e "      ${CYAN}╚════════════════════════╝${RESET}"
echo -e "            ${GREY}██████████████████${RESET}"
}

# PRESSED BUTTON
button_pressed() {
echo -e "        ${CYAN}╔════════════════════════╗${RESET}"
echo -e "        ${CYAN}║${RESET}  $1${RESET}"
echo -e "        ${CYAN}╚════════════════════════╝${RESET}"
echo -e "      ${GREY}██████████████████${RESET}"
}

# CLICK SOUND
click() { printf "\a"; }

# AUTO START WATCHER
start_watcher() {
echo "while true; do
PID=\$(pgrep -f \"$BOT\")
if [ -z \"\$PID\" ]; then
    bash runpy.sh \"$BOT\" start
fi
sleep 2
done" > autostart.sh

chmod +x autostart.sh
nohup bash autostart.sh >/dev/null 2>&1 &
echo "AUTO_START_PID=$!" > watcher.pid
}

# STOP WATCHER
stop_watcher() {
if [ -f watcher.pid ]; then
    source watcher.pid
    kill -9 "$AUTO_START_PID" 2>/dev/null
    rm -f watcher.pid autostart.sh
fi
}

while true; do
clear
echo -e "${MAGENTA}🔥 PYTHON BOT CONTROL PANEL (3D + SOUND + AUTO START) 🔥${RESET}"
echo -e "${CYAN}══════════════════════════════════════════${RESET}"
echo ""

button_normal "${GREEN}[1] START BOT${RESET}"
button_normal "${RED}[2] STOP BOT${RESET}"
button_normal "${BLUE}[3] RESTART BOT${RESET}"
button_normal "${CYAN}[4] STATUS${RESET}"
button_normal "${YELLOW}[5] VIEW LOGS${RESET}"
button_normal "${MAGENTA}[6] AUTO START 24/7${RESET}"
button_normal "${RED}[7] AUTO STOP${RESET}"
button_normal "${RED}[8] EXIT${RESET}"

echo ""
echo -ne "${GREEN}👉 Select: ${RESET}"
read opt

clear
echo -e "${MAGENTA}🔥 PYTHON BOT CONTROL PANEL (3D + SOUND + AUTO START) 🔥${RESET}"
echo -e "${CYAN}══════════════════════════════════════════${RESET}"
echo ""

case "$opt" in
1)
    click
    button_pressed "${GREEN}[1] START BOT${RESET}"
    bash runpy.sh "$BOT" start
    sleep 1
    ;;
2)
    click
    button_pressed "${RED}[2] STOP BOT${RESET}"
    bash runpy.sh "$BOT" stop
    sleep 1
    ;;
3)
    click
    button_pressed "${BLUE}[3] RESTART BOT${RESET}"
    bash runpy.sh "$BOT" restart
    sleep 1
    ;;
4)
    click
    button_pressed "${CYAN}[4] STATUS${RESET}"
    bash runpy.sh "$BOT" status
    read
    ;;
5)
    click
    button_pressed "${YELLOW}[5] VIEW LOGS${RESET}"
    cat logs/$BOT.log 2>/dev/null || echo -e "${RED}No log file.${RESET}"
    read
    ;;
6)
    click
    button_pressed "${MAGENTA}[6] AUTO START ENABLED${RESET}"
    start_watcher
    echo -e "${GREEN}Auto-start ON!${RESET}"
    sleep 2
    ;;
7)
    click
    button_pressed "${RED}[7] AUTO START DISABLED${RESET}"
    stop_watcher
    echo -e "${RED}Auto-start stopped.${RESET}"
    sleep 2
    ;;
8)
    click
    button_pressed "${RED}[8] EXIT${RESET}"
    exit
    ;;
*)
    echo -e "${RED}Invalid!${RESET}"
    sleep 1
    ;;
esac

done
